import os
import requests
from multiprocessing.dummy import Pool
from colorama import Fore, init
import time
from random import choice
import ctypes
import sys

init(autoreset=True)
fr = Fore.RED
fw = Fore.WHITE
fg = Fore.GREEN
fc = Fore.CYAN

Bad = 0
Good = 0

def clear():
    try:
        if os.name == 'nt':
            os.system('cls')
        else:
            os.system('clear')
    except:
        pass

def finder(i):
    global Bad, Good
    head = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'}
    try:
        x = requests.session()
        listaa = ['/.well-known/acme-challenge/file.php','/.well-known/pki-validation/file.php','/cgi-bin/file.php','/file.php','/wp-admin/images/file.php','/wp-admin/includes/file.php','/wp-admin/js/widgets/file.php','/wp-admin/maint/file.php','/wp-admin/network/file.php','/wp-admin/user/file.php','/wp-content/languages/file.php','/wp-content/languages/themes/file.php','/wp-content/plugins/file.php','/wp-includes/SimplePie/file.php','/wp-includes/certificates/file.php','/wp-includes/customize/file.php']
        for script in listaa:
            url = (i + "/" + script)
            while True:
                req_first = x.get(url, headers=head)
                if "-rw-r--r--" in req_first.text:
                    Good = Good + 1
                    print(fg + "[*]" + fw + ">> " + fg + " = " + url)
                    with open("shell.txt", "a") as file:
                        file.write(url + "\n")
                        file.close()
                else:
                    Bad = Bad + 1
                    print(fc + "" + fw + "[" + fr + "*" + fw + "] " + fr + " " + i + " " + fw + " >>> " + fr + " [Not Vuln]")
                    pass
                break
    except:
        pass
    if os.name == 'nt':
        ctypes.windll.kernel32.SetConsoleTitleW('Funs | Found-{} | Not Vuln-{}'.format(Good, Bad))
    else:
        sys.stdout.write('\x1b]2; Funs | Found-{} | Not Vuln-{}\x07'.format(Good, Bad))

def key_logo():
    clear = '\x1b[0m'
    colors = [36, 32, 34, 35, 31, 37]
    x = '          [ + ] Funs'
    for N, line in enumerate(x.split('\n')):
        sys.stdout.write('\x1b[1;%dm%s%s\n' % (choice(colors), line, clear))
        time.sleep(0.05)

def run():
    key_logo()
    clear()
    print(""" \033[0;32m
 FlashKiss
""")
    file_name = input("\033[0;32mWebsite List : ")
    op = open(file_name, 'r').read().splitlines()
    TEXTList = [list.strip() for list in op]
    p = Pool(int(input('\033[0;31mThreads : ')))
    p.map(finder, TEXTList)

run()
input() 
